import React from "react";

const Workshop = () => {
  return (
    <>
      <div>
        <img
          src="https://s3-alpha-sig.figma.com/img/9615/c845/fa61cd33b8d681ea72293a122d8fed06?Expires=1698624000&Signature=UmuI0pkLYSvTsup2obwi4T3y1ZSn3FTp--SkOosWKTwWVcLrguOPnT0ddRXClOgLDdRZ122MJkYeT8IWsvz3PXFsFOTLbBecwlXO04em4-iY62QoEH8BkDiAnSkk4CVS3xcNCtUfS0PWWbcVJXyk9wmEJ7jrU-WvqIolgb628BLuU5stCRCmfz1CDYU~j1gTqUE5dDqQ~M4PKlkK7WYu0aiQ5a-~aO4EmMbWaoFHQuGqGm0cIi-fILN2bAEc-lWIvYPovnmkWW16gsstL43DFrx7BlYyva~hiZNXvhpaxzwg9Pnm4FYrBrsjHxxy6qcAnhbj0TfjKZ3eTwjioXys5w__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
          alt=""
        />
      </div>
      <div>
        <img
          src="https://s3-alpha-sig.figma.com/img/7616/9b38/b902ce841ecb52dcc7c3fa1260b77226?Expires=1698624000&Signature=FEZ4iApjiUwJ19-myq1lCBlcrIYF1aKSckRvTMEAg7beh9xqimAzwLmWWR2EGiEoRKOrl9jh6uCW3J5wAUfXGkVrEdEiAkgLvicCVx6CrRTvQkoYMPnt8F6d~Q4YluXnLKO7e-cPh2dE8VJNQ7rR4~hhbjCCk6iUCo85qc8hlJOczZcJa8YOxN8ZA3UH8pNrmkXM-a-RQtI3TcyEhDKXvNwQ0wX-9G1RWe9nJQDk~PwjnHW8hcs61gWHAmgdY9YaLbsAAGjaePwzGD4QgJrY9z993CykcZSne5BSiu7~~P1-Z1wqiE3pWacIXxHgXBgzZRAEyb-rPJ3EwMwFrb9gkw__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
          alt=""
        />
      </div>
      <div>
        <img
          src="https://s3-alpha-sig.figma.com/img/d35b/4884/1875359dfd3f6e19a1cd171c8fd01033?Expires=1698624000&Signature=eQirX0MuVf47~YGVsUDLNFsSWs~uRM3ImdnbBPR~ZloLHp6zVwuB2cmfZwCtWbuA5I3p8I1n2CygBUkEHHNI9z0irgJxNqpxyDzJc9-TjMaZPXgAK7KASFWkf8RD7wsObwK7129WaqkXdaAiAXYZWRBkAxWGGUNl2pqlX6LgLaoXTvTKvn5sZ8BSbFMtM1HcESZewZHPpDd0WWhWwqKfv4cy2-61o6~N~3u1pZNTRdCEDLg4a7cNqizNHvTp7Dv48j3xqCskMBS4kTJBCS0FaCnizRXcvfMa0zybnl4Oo~czleGBjG4Xt2PsEabCJVEKZ-3~iaakfTXpN1uEvIWfMg__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
          alt=""
        />
      </div>
    </>
  );
};

export default Workshop;
